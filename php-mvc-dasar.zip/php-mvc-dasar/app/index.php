<?php

echo "Halo halaman ini seharusnya tidak bisa di akses";